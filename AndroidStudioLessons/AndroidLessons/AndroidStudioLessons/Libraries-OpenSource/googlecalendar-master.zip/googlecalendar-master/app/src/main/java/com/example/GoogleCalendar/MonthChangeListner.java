package com.example.GoogleCalendar;

public interface MonthChangeListner {
    void onmonthChange(MonthModel monthModel);
}
