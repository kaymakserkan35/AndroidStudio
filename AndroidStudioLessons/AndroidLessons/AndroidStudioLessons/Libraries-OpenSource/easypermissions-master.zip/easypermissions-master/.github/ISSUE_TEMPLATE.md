## Basic Information

Device type: ________
OS version: ________
EasyPermissions version: ________

## Describe the problem

What happened?  What did you expect to happen?

## Code and logs

```
// TODO(you): show the code that produces the problem,
//            and any relevant logs.
```
